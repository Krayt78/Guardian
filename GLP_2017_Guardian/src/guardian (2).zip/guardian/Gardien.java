package guardian;

public class Gardien {
	private String guardien ="g";
	
	public String getg() {
		return guardien;
	}
	public void setg(String g) {
		this.guardien = guardien;
	}
		
}
