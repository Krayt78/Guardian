package guardian;

import java.util.Random;

public class Grille {
	private int demension;
	private Case[][] grille;
	private String gardian =" g ";
	private Obstacles[] o = {new Obstacles("*"),new Obstacles("a"),new Obstacles("e"),new Obstacles("m"),new Obstacles("g")};
	private Case c;
	
	
	
	
	public Grille(int n){
		
		this.demension=n;
		grille =new Case[demension][demension];
		
		for(int i= 0 ; i<demension ;i++){
			
			for(int j=0;j<demension ;j++){
				//o[j]=new Obstacles("*");
				grille[i][j]=new Case(o[0]); //new Case(o[j]);
			}
		}
	}
	
	public void placerJ(int ligne ,int colone ){
		ligne =ligne-1;
		colone --;
		
		if(ligne>=0 &&colone >=0 && ligne<this.demension&&colone <this.demension){
			grille[ligne][colone]=new Case(o[4]);
		}
		else{
			System.out.println("Erreur le grrdien ne peut pas etre dehore la grille!! ");
			return;
		}
		
		
		 
	}
	
	public void placerObs(int n){
		Random r = new Random();
		int x ,y;
		int k = n/3;
		
		//o=new Obstacles[n];
		for(int i =0 ;i<k;i++){
			x=r.nextInt(k);
			y=r.nextInt(k);
		//	o[i]=new Obstacles("a");
			grille[x][y]=new Case(o[1]);
		}
		for(int i =0 ;i<k;i++){
			x=r.nextInt(n);
			y=r.nextInt(n);
			//o[i]=new Obstacles("m");
			grille[x][y]=new Case(o[3]);
		}
		for(int i =0 ;i<k;i++){
			x=r.nextInt(n);
			y=r.nextInt(n);
			//o[i]=new Obstacles("e");
			grille[x][y]=new Case(o[2]);
		}
		
	}
	
	public void deplacerH(){
		Obstacles tmp=null;
		int ligne=0; int colone=0;
		for(int i =0 ;i<grille.length ;i++){
			for(int j =0 ;j<grille.length ;j++){
				if(grille[i][j].getO()==o[4]){
					tmp =grille[i][j].getO();
					ligne =i;
					colone=j;
					break;
				}
			}
			if(tmp!=null)
			  break;
		}
		if(ligne-1>=0 && grille[ligne-1][colone].getO()!=o[1] && grille[ligne-1][colone].getO()!=o[2] && grille[ligne-1][colone].getO()!=o[3] ){
			grille[ligne-1][colone].setO(tmp);
			grille[ligne][colone].setO(o[0]);
		
	    }
	}
	/*	else if (grille[ligne-1][colone]==obstacle)
		{
			if 
		}
		else
		{
			System.out.println("Vous sortez de la grille !! ");
		} 9*/
	
	public void deplacerB(){
		Obstacles tmp=null;
		int ligne=0; int colone=0;
		for(int i =0 ;i<grille.length ;i++){
			for(int j =0 ;j<grille.length ;j++){
				if(grille[i][j].getO()==o[4]){
					tmp =grille[i][j].getO();
					ligne =i;
					colone=j;
					break;
				}
			}
			if(tmp!=null)
			  break;	
		}
		if(ligne-1>=0 && grille[ligne-1][colone].getO()!=o[1] && grille[ligne-1][colone].getO()!=o[2] && grille[ligne-1][colone].getO()!=o[3] ){
			grille[ligne+1][colone].setO(tmp);
			grille[ligne][colone].setO(o[0]);
		
	    }
	}
	
	public void deplacerD(){
		Obstacles tmp=null;
		int ligne=0; int colone=0;
		for(int i =0 ;i<grille.length ;i++){
			for(int j =0 ;j<grille.length ;j++){
				if(grille[i][j].getO()==o[4]){
					tmp =grille[i][j].getO();
					ligne =i;
					colone=j;
					break;
				}
			}
			if(tmp!=null)
			  break;
		}
		if(ligne-1>=0 && grille[ligne-1][colone].getO()!=o[1] && grille[ligne-1][colone].getO()!=o[2] && grille[ligne-1][colone].getO()!=o[3] ){
			grille[ligne][colone+1].setO(tmp);
			grille[ligne][colone].setO(o[0]);
		
	    }
	}
	
	public void deplacerG(){
		Obstacles tmp=null;
		int ligne=0; int colone=0;
		for(int i =0 ;i<grille.length ;i++){
			for(int j =0 ;j<grille.length ;j++){
				if(grille[i][j].getO()==o[4]){
					tmp =grille[i][j].getO();
					ligne =i;
					colone=j;
					break;
				}
			}
			if(tmp!=null)
			  break;
		}
		if(ligne-1>=0 && grille[ligne-1][colone].getO()!=o[1] && grille[ligne-1][colone].getO()!=o[2] && grille[ligne-1][colone].getO()!=o[3] ){
			grille[ligne][colone-1].setO(tmp);
			grille[ligne][colone].setO(o[0]);
		
	    }
	}
	
	
	
	public Case getCase(int ligne ,int colone){
		ligne --;
		colone --;
		return this.grille[ligne][colone];
	}
	
	
	public String toString(){
		String s="";
		for(int i =0 ;i<grille.length ; i++){
			for(int j=0 ;j<grille.length; j++){
				s+="|" +grille[i][j].getO().getType();
			}
			s+="|";
			s+="\n";
		}
		
		return s;
	}

}
