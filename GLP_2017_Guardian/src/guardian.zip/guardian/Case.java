package guardian;

public class Case {
	private Obstacles o;
	public Case (Obstacles o)
	{
		this.o=o;
	}
	public Obstacles getO() {
		return o;
	}
	public void setO(Obstacles o) {
		this.o = o;
	}

}
