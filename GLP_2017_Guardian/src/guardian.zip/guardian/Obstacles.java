package guardian;

public class Obstacles{
	private String type;
	
	public Obstacles(String type)
	{
		this.type = type;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public void Arbre()
	{
		
	}
	
	public void vide()
	{
		
	}

/*	public int Quelobstacle()
	{
		if()
		{
			move = 1;
			voir = 0;
			
		}
		if(esteau)
		{
			move = 0;
			voir = 1;
		}
		if(estmur)
		{
			move = voir = 0 ;
		}
		
	} */
	


}
